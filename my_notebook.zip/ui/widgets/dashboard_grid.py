from PySide6.QtWidgets import QWidget, QGridLayout, QScrollArea, QFrame

class DashboardGrid(QWidget):
    def __init__(
        self,
        min_cell_width: int = 220,
        max_cell_width: int = 300,
        cell_ratio: float = 0.70,
        spacing: int = 20,
    ):
        super().__init__()

        self.min_cell_width = min_cell_width
        self.max_cell_width = max_cell_width
        self.cell_ratio = cell_ratio
        self.spacing = spacing

        self.items = []
        self.occupied_cells = []
        self.card_positions = {}
        self.current_columns = 1
        self.drop_preview = QFrame(self)
        self.drop_preview.hide()

        self.layout = QGridLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(spacing)

        self.card_positions = {}

        self._last_cell_width = self.min_cell_width
        self._last_cell_height = int(self.min_cell_width * self.cell_ratio)

    def add_card(
        self,
        widget,
        size: str = "1x1",
    ) -> None:
        self.items.append(
            {
                "widget": widget,
                "size": size,
            }
        )

        self._rebuild_grid()

    def resizeEvent(self, event) -> None:
        self._rebuild_grid()
        super().resizeEvent(event)

    def _rebuild_grid(self) -> None:
        if not self.items:
            return

        self._clear_layout()
        self.occupied_cells = []

        parent_width = self.parentWidget().width() if self.parentWidget() else self.width()

        available_width = max(
            self._get_available_width(),
            self.min_cell_width,
        )

        self.current_columns = self._calculate_columns(
            available_width
        )

        cell_width = self._calculate_cell_width(
            available_width,
            self.current_columns,
        )

        cell_height = int(cell_width * self.cell_ratio)
        self._last_cell_width = cell_width
        self._last_cell_height = cell_height

        for item in self.items:
            widget = item["widget"]
            size = item["size"]

            width_units, height_units = self._parse_size(size)

            row, column = self._find_available_position(
                width_units,
                height_units,
            )

            real_width = (
                cell_width * width_units
                + self.spacing * (width_units - 1)
            )

            real_height = (
                cell_height * height_units
                + self.spacing * (height_units - 1)
            )

            if hasattr(widget, "set_base_size"):
                scale = getattr(widget, "scale", 1)

                widget.set_base_size(
                    int(real_width / scale),
                    int(real_height / scale),
                )

            self.layout.addWidget(
                widget,
                row,
                column,
                height_units,
                width_units,
            )

            self.card_positions[widget] = {
                "row": row,
                "column": column,
                "width_units": width_units,
                "height_units": height_units,
            }

            self._mark_cells_as_occupied(
                row,
                column,
                width_units,
                height_units,
            )

    def _get_available_width(self) -> int:
        parent = self.parentWidget()

        while parent is not None:
            if isinstance(parent, QScrollArea):
                return parent.viewport().width()

            parent = parent.parentWidget()

        return self.width()

    def _calculate_columns(
            self,
            available_width: int,
    ) -> int:

        minimum_column_width = (
                self.min_cell_width
                + self.spacing
        )

        columns = available_width // minimum_column_width

        return max(3, columns)

    def _calculate_cell_width(
            self,
            available_width: int,
            columns: int,
    ) -> int:
        total_spacing = self.spacing * (columns - 1)

        cell_width = (
                             available_width - total_spacing
                     ) // columns

        return min(
            self.max_cell_width,
            max(self.min_cell_width, cell_width),
        )

    def _parse_size(self, size: str) -> tuple[int, int]:
        width, height = size.lower().split("x")

        return int(width), int(height)

    def _find_available_position(
        self,
        width_units: int,
        height_units: int,
    ) -> tuple[int, int]:
        row = 0

        while True:
            for column in range(self.current_columns):
                if self._can_place_card(
                    row,
                    column,
                    width_units,
                    height_units,
                ):
                    return row, column

            row += 1

    def _can_place_card(
        self,
        row: int,
        column: int,
        width_units: int,
        height_units: int,
    ) -> bool:
        if column + width_units > self.current_columns:
            return False

        for r in range(row, row + height_units):
            for c in range(column, column + width_units):
                if (r, c) in self.occupied_cells:
                    return False

        return True

    def _mark_cells_as_occupied(
        self,
        row: int,
        column: int,
        width_units: int,
        height_units: int,
    ) -> None:
        for r in range(row, row + height_units):
            for c in range(column, column + width_units):
                self.occupied_cells.append((r, c))

    def get_cards_in_area(
            self,
            row: int,
            column: int,
            width_units: int,
            height_units: int,
    ) -> list:

        target_cells = set()

        for r in range(row, row + height_units):
            for c in range(column, column + width_units):
                target_cells.add((r, c))

        conflicting_cards = []

        for widget, position in self.card_positions.items():
            widget_cells = set()

            widget_row = position["row"]
            widget_column = position["column"]
            widget_width = position["width_units"]
            widget_height = position["height_units"]

            for r in range(widget_row, widget_row + widget_height):
                for c in range(widget_column, widget_column + widget_width):
                    widget_cells.add((r, c))

            if target_cells.intersection(widget_cells):
                conflicting_cards.append(widget)

        return conflicting_cards

    def can_drop_card_at(
            self,
            row: int,
            column: int,
            width_units: int,
            height_units: int,
    ) -> bool:

        if column + width_units > self.current_columns:
            return False

        return True

    def _clear_layout(self) -> None:
        while self.layout.count():
            item = self.layout.takeAt(0)

            if item.widget():
                self.layout.removeWidget(item.widget())

    def get_cell_from_global_position(
            self,
            global_pos,
    ) -> tuple[int, int] | None:

        local_pos = self.mapFromGlobal(global_pos)

        if not self.rect().contains(local_pos):
            return None

        cell_width = self._last_cell_width
        cell_height = self._last_cell_height

        total_cell_width = cell_width + self.spacing
        total_cell_height = cell_height + self.spacing

        column = local_pos.x() // total_cell_width
        row = local_pos.y() // total_cell_height

        if column < 0 or column >= self.current_columns:
            return None

        return row, column

    def show_drop_preview(
            self,
            row: int,
            column: int,
            width_units: int,
            height_units: int,
            valid: bool,
    ) -> None:

        cell_width = self._last_cell_width
        cell_height = self._last_cell_height

        x = column * (cell_width + self.spacing)
        y = row * (cell_height + self.spacing)

        width = (
                cell_width * width_units
                + self.spacing * (width_units - 1)
        )

        height = (
                cell_height * height_units
                + self.spacing * (height_units - 1)
        )

        if valid:
            color = "rgba(34, 197, 94, 55)"
            border = "rgba(34, 197, 94, 150)"
        else:
            color = "rgba(239, 68, 68, 45)"
            border = "rgba(239, 68, 68, 140)"

        self.drop_preview.setStyleSheet(f"""
            QFrame {{
                background-color: {color};
                border: 2px dashed {border};
                border-radius: 18px;
            }}
        """)

        self.drop_preview.setGeometry(
            x,
            y,
            width,
            height,
        )

        self.drop_preview.show()
        self.drop_preview.raise_()

    def hide_drop_preview(self) -> None:
        self.drop_preview.hide()

    def move_card_to(
            self,
            widget,
            row: int,
            column: int,
    ) -> None:

        if widget not in self.card_positions:
            return

        position = self.card_positions[widget]

        width_units = position["width_units"]
        height_units = position["height_units"]

        self.layout.removeWidget(widget)

        self.card_positions[widget] = {
            "row": row,
            "column": column,
            "width_units": width_units,
            "height_units": height_units,
        }

        self._rebuild_grid_from_positions()

    def _rebuild_grid_from_positions(self) -> None:
        self._clear_layout()
        self.occupied_cells = []

        for widget, position in self.card_positions.items():
            row = position["row"]
            column = position["column"]
            width_units = position["width_units"]
            height_units = position["height_units"]

            self.layout.addWidget(
                widget,
                row,
                column,
                height_units,
                width_units,
            )

            self._mark_cells_as_occupied(
                row,
                column,
                width_units,
                height_units,
            )