from core.database.database_manager import DatabaseManager


class FinanceCategoryRepository:
    def __init__(
            self,
            username: str,
    ) -> None:
        self.database = DatabaseManager(username)
        self.conexao = self.database.get_connection()

    def listar_ativas(self) -> list[dict]:
        cursor = self.conexao.cursor()

        cursor.execute(
            """
            SELECT
                id,
                display_number,
                name,
                color,
                is_active,
                is_protected
            FROM finance_categories
            WHERE is_active = 1
            ORDER BY display_number ASC, name ASC
            """
        )

        return [
            dict(row)
            for row in cursor.fetchall()
        ]

    def criar(
            self,
            name: str,
            color: str,
            display_number: int,
    ) -> int:
        cursor = self.conexao.cursor()

        cursor.execute(
            """
            INSERT INTO finance_categories (
                display_number,
                name,
                color,
                is_active,
                is_protected
            )
            VALUES (?, ?, ?, 1, 0)
            """,
            (
                display_number,
                name,
                color,
            ),
        )

        self.conexao.commit()

        return cursor.lastrowid

    def atualizar(
            self,
            category_id: int,
            name: str,
            color: str,
            display_number: int,
    ) -> None:
        cursor = self.conexao.cursor()

        cursor.execute(
            """
            UPDATE finance_categories
            SET
                name = ?,
                color = ?,
                display_number = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
              AND is_protected = 0
            """,
            (
                name,
                color,
                display_number,
                category_id,
            ),
        )

        self.conexao.commit()

    def desativar(
            self,
            category_id: int,
    ) -> None:
        cursor = self.conexao.cursor()

        cursor.execute(
            """
            UPDATE finance_categories
            SET
                is_active = 0,
                display_number = 999,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
              AND is_protected = 0
            """,
            (category_id,),
        )

        self.conexao.commit()

    def listar_todas(self) -> list[dict]:
        cursor = self.conexao.cursor()

        cursor.execute(
            """
            SELECT
                id,
                display_number,
                name,
                color,
                is_active,
                is_protected
            FROM finance_categories
            ORDER BY
                is_active DESC,
                CASE
                    WHEN display_number IS NULL THEN 999
                    ELSE display_number
                END ASC,
                name ASC
            """
        )

        return [dict(row) for row in cursor.fetchall()]

    def reativar(
            self,
            category_id: int,
            display_number: int,
    ) -> None:
        cursor = self.conexao.cursor()

        cursor.execute(
            """
            UPDATE finance_categories
            SET
                is_active = 1,
                display_number = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (
                display_number,
                category_id,
            ),
        )

        self.conexao.commit()

    def obter_proximo_display_number(self) -> int:
        cursor = self.conexao.cursor()

        cursor.execute(
            """
            SELECT COALESCE(MAX(display_number), 0) + 1 AS next_number
            FROM finance_categories
            WHERE is_active = 1
              AND display_number < 99
            """
        )

        row = cursor.fetchone()

        return int(row["next_number"])

    def buscar_por_nome(
            self,
            name: str,
    ) -> dict | None:
        cursor = self.conexao.cursor()

        cursor.execute(
            """
            SELECT
                id,
                display_number,
                name,
                color,
                is_active,
                is_protected
            FROM finance_categories
            WHERE LOWER(name) = LOWER(?)
            LIMIT 1
            """,
            (name,),
        )

        row = cursor.fetchone()

        if row is None:
            return None

        return dict(row)